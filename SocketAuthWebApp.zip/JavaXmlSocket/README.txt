<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<response>
<SessionId/>
<EventType>Authentication</EventType>
<event>
<EventCode>1</EventCode>
</event>
<data>
<ErrorCode>3</ErrorCode>
<ErrorText>Invalid user</ErrorText>
<AeonErrorCode>103</AeonErrorCode>
<AeonErrorText>Invalid User</AeonErrorText>
</data>
</response>
